package com.bitam.Telemedicine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TelemedicineApplicationTests {

	@Test
	void contextLoads() {
	}

}
